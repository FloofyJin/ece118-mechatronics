/*
 * File:   BasicMain.c
 * Author: jpark598
 *
 * Created on April 12, 2024, 6:57 PM
 */


#include "xc.h"

int main(void) {
    return 0;
}
