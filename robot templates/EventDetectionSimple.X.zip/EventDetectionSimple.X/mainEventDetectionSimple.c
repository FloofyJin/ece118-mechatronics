/*
 * File:   mainEventDetectionSimple.c
 * Author: rianb
 *
 * Created on April 11, 2023, 7:05 PM
 */


#include "xc.h"

int main(void) {
    return 0;
}
