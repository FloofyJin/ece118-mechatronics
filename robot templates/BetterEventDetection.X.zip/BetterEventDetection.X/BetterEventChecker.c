/*
 * File:   TemplateEventChecker.c
 * Author: Gabriel Hugh Elkaim
 *
 * Template file to set up typical EventCheckers for the  Events and Services
 * Framework (ES_Framework) on the Uno32 for the CMPE-118/L class. Note that
 * this file will need to be modified to fit your exact needs, and most of the
 * names will have to be changed to match your code.
 *
 * This EventCheckers file will work with both FSM's and HSM's.
 *
 * Remember that EventCheckers should only return TRUE when an event has occured,
 * and that the event is a TRANSITION between two detectable differences. They
 * should also be atomic and run as fast as possible for good results.
 *
 * This file includes a test harness that will run the event detectors listed in the
 * ES_Configure file in the project, and will conditionally compile main if the macro
 * EVENTCHECKER_TEST is defined (either in the project or in the file). This will allow
 * you to check you event detectors in their own project, and then leave them untouched
 * for your project unless you need to alter their post functions.
 *
 * Created on September 27, 2013, 8:37 AM
 */

/*******************************************************************************
 * MODULE #INCLUDE                                                             *
 ******************************************************************************/

#include "ES_Configure.h"
#include "BetterEventChecker.h"
#include "ES_Events.h"
#include "serial.h"
#include "AD.h"


/*******************************************************************************
 * MODULE #DEFINES                                                             *
 ******************************************************************************/
#define BATTERY_DISCONNECT_THRESHOLD 175
#define DARK_THRESHOLD 530
#define LIGHT_THRESHOLD 470


/*******************************************************************************
 * EVENTCHECKER_TEST SPECIFIC CODE                                                             *
 ******************************************************************************/

//#define EVENTCHECKER_TEST
#ifdef EVENTCHECKER_TEST
#include <stdio.h>
#include <BOARD.h>
#include "roach.h"
#define SaveEvent(x) do {eventName=__func__; storedEvent=x;} while (0)

static const char *eventName;
static ES_Event storedEvent;
#endif

/*******************************************************************************
 * PRIVATE FUNCTION PROTOTYPES                                                 *
 ******************************************************************************/
/* Prototypes for private functions for this EventChecker. They should be functions
   relevant to the behavior of this particular event checker */

/*******************************************************************************
 * PRIVATE MODULE VARIABLES                                                    *
 ******************************************************************************/

/* Any private module level variable that you might need for keeping track of
   events would be placed here. Private variables should be STATIC so that they
   are limited in scope to this module. */

/*******************************************************************************
* PUBLIC FUNCTIONS                                                            *
******************************************************************************/

/**
* @Function CheckBatteryConnected(void)
* @param none
* @return TRUE or FALSE
* @brief This function is a prototype event checker that checks the battery voltage
*        against a fixed threshold (#defined in the .c file). Note that you need to
*        keep track of previous history, and that the actual battery voltage is checked
*        only once at the beginning of the function. The function will post an event
*        of either BATTERY_CONNECTED or BATTERY_DISCONNECTED if the power switch is turned
*        on or off with the USB cord plugged into the Uno32. Returns TRUE if there was an
*        event, FALSE otherwise.
* @note Use this code as a template for your other event checkers, and modify as necessary.
* @author Gabriel H Elkaim, 2013.09.27 09:18
* @modified Gabriel H Elkaim/Max Dunne, 2016.09.12 20:08 */
uint8_t CheckBatteryConnected(void) {
   static ES_EventTyp_t lastEvent = BATTERY_DISCONNECTED;
   ES_EventTyp_t curEvent;
   ES_Event thisEvent;
   uint8_t returnVal = FALSE;
   uint16_t batVoltage = AD_ReadADPin(BAT_VOLTAGE); // read the battery voltage

   if (batVoltage > BATTERY_DISCONNECT_THRESHOLD) { // is battery connected?
       curEvent = BATTERY_CONNECTED;
   } else {
       curEvent = BATTERY_DISCONNECTED;
   }
   if (curEvent != lastEvent) { // check for change from last time
       thisEvent.EventType = curEvent;
       thisEvent.EventParam = batVoltage;
       returnVal = TRUE;
       lastEvent = curEvent; // update history
#ifndef EVENTCHECKER_TEST           // keep this as is for test harness
       PostGenericService(thisEvent);
#else
       SaveEvent(thisEvent);
#endif
   }
   return (returnVal);
}

/**
* @Function TemplateCheckBattery(void)
* @param none
* @return TRUE or FALSE
* @brief This function is a prototype event checker that checks the battery voltage
*        against a fixed threshold (#defined in the .c file). Note that you need to
*        keep track of previous history, and that the actual battery voltage is checked
*        only once at the beginning of the function. The function will post an event
*        of either BATTERY_CONNECTED or BATTERY_DISCONNECTED if the power switch is turned
*        on or off with the USB cord plugged into the Uno32. Returns TRUE if there was an
*        event, FALSE otherwise.
* @note Use this code as a template for your other event checkers, and modify as necessary.
* @author Gabriel H Elkaim, 2013.09.27 09:18
* @modified Gabriel H Elkaim/Max Dunne, 2016.09.12 20:08 */
uint8_t CheckLightLevel(void) {
   static ES_EventTyp_t lastLightState = IN_LIGHT;
   static uint16_t Threshold = DARK_THRESHOLD;
   ES_EventTyp_t currentLightState;
   ES_Event thisEvent;
   uint8_t returnVal = FALSE;
   uint16_t currentLightValue = Roach_LightLevel(); // read the battery voltage

   if (currentLightValue >= Threshold) {
       currentLightState = IN_DARK;
       Threshold = LIGHT_THRESHOLD;
   } else {
       currentLightState = IN_LIGHT;
       Threshold = DARK_THRESHOLD;
   }

   if (currentLightState != lastLightState) { //event detected
       thisEvent.EventType = currentLightState;
       thisEvent.EventParam = (uint16_t) currentLightValue;
       returnVal = TRUE;
       lastLightState = currentLightState;
#ifndef EVENTCHECKER_TEST           // keep this as is for test harness
       PostGenericService(thisEvent);
#else
       SaveEvent(thisEvent);
#endif
   }
   return returnVal;
}


uint8_t CheckRearLeftBumperPressed(void){
    static uint8_t lastBumperStates_RL[3] = { BUMPER_NOT_TRIPPED,
                                            BUMPER_NOT_TRIPPED, BUMPER_NOT_TRIPPED};

    static ES_EventTyp_t lastBumperState_RL = REAR_LEFT_UNPRESSED;
    ES_EventTyp_t currentBumperState_RL;
    ES_Event thisEvent;
    uint8_t returnVal = FALSE;
    uint16_t currentBumperVal_RL = Roach_ReadRearLeftBumper(); // read the bumper value
    // IF bumper was PRESSED for 3 states AND was UNPRESSED 4 states ago => TRANSITION
    if ( (currentBumperVal_RL != lastBumperStates_RL[2]) && (currentBumperVal_RL == lastBumperStates_RL[1]) &&
         (currentBumperVal_RL == lastBumperStates_RL[0]) && (currentBumperVal_RL == BUMPER_TRIPPED)) {
        
        if(currentBumperVal_RL == BUMPER_TRIPPED){
            currentBumperState_RL = REAR_LEFT_PRESSED;
            thisEvent.EventType = currentBumperState_RL;
            thisEvent.EventParam = (uint16_t) currentBumperVal_RL;
            returnVal = TRUE;
            lastBumperState_RL = currentBumperState_RL;
        }
        else{
            currentBumperState_RL = REAR_LEFT_UNPRESSED;
       thisEvent.EventType = currentBumperState_RL;
        thisEvent.EventParam = (uint16_t) currentBumperVal_RL;
        returnVal = TRUE;
        lastBumperState_RL = currentBumperState_RL;
        }
        
// #ifndef EVENTCHECKER_TEST           // keep this as is for test harness
//         PostGenericService(thisEvent);
// #else
//         SaveEvent(thisEvent);
// #endif
#ifndef SIMPLESERVICE_TEST           // keep this as is for test harness
        printf("POSTING GENERIC SERVICE\r\n");
        PostGenericService(thisEvent);
#else
        printf("POSTING TEMPLATE SERVICE\r\n");
        PostTemplateService(thisEvent);
#endif
    } else {
       currentBumperState_RL = REAR_LEFT_UNPRESSED;
    }

    lastBumperStates_RL[2] = lastBumperStates_RL[1];
    lastBumperStates_RL[1] = lastBumperStates_RL[0];
    lastBumperStates_RL[0] = currentBumperVal_RL;

    return returnVal;
}

uint8_t CheckRearRightBumperPressed(void){
    static uint8_t lastBumperStates_RR[3] = { BUMPER_NOT_TRIPPED,
                                            BUMPER_NOT_TRIPPED, BUMPER_NOT_TRIPPED};

    static ES_EventTyp_t lastBumperState_RR = REAR_RIGHT_UNPRESSED;
    ES_EventTyp_t currentBumperState_RR;
    ES_Event thisEvent;
    uint8_t returnVal = FALSE;
    uint16_t currentBumperVal_RR = Roach_ReadRearRightBumper(); // read the bumper value
    // IF bumper was PRESSED for 3 states AND was UNPRESSED 4 states ago => TRANSITION
    if ( (currentBumperVal_RR != lastBumperStates_RR[2]) && (currentBumperVal_RR == lastBumperStates_RR[1]) &&
         (currentBumperVal_RR == lastBumperStates_RR[0]) && (currentBumperVal_RR == BUMPER_TRIPPED)) {
        currentBumperState_RR = REAR_RIGHT_PRESSED;
        thisEvent.EventType = currentBumperState_RR;
        thisEvent.EventParam = (uint16_t) currentBumperVal_RR;
        returnVal = TRUE;
        lastBumperState_RR = currentBumperState_RR;
#ifndef EVENTCHECKER_TEST           // keep this as is for test harness
        PostGenericService(thisEvent);
#else
        SaveEvent(thisEvent);
#endif
    } else {
       currentBumperState_RR = REAR_RIGHT_UNPRESSED;
    }

    lastBumperStates_RR[2] = lastBumperStates_RR[1];
    lastBumperStates_RR[1] = lastBumperStates_RR[0];
    lastBumperStates_RR[0] = currentBumperVal_RR;

    return returnVal;
}

uint8_t CheckFrontLeftBumperPressed(void){
    static uint8_t lastBumperStates_FL[3] = { BUMPER_NOT_TRIPPED,
                                            BUMPER_NOT_TRIPPED, BUMPER_NOT_TRIPPED};

    static ES_EventTyp_t lastBumperState_FL = FRONT_LEFT_UNPRESSED;
    ES_EventTyp_t currentBumperState_FL;
    ES_Event thisEvent;
    uint8_t returnVal = FALSE;
    uint16_t currentBumperVal_FL = Roach_ReadFrontLeftBumper(); // read the bumper value
    // IF bumper was PRESSED for 3 states AND was UNPRESSED 4 states ago => TRANSITION
    if ( (currentBumperVal_FL != lastBumperStates_FL[2]) && (currentBumperVal_FL == lastBumperStates_FL[1]) &&
         (currentBumperVal_FL == lastBumperStates_FL[0]) && (currentBumperVal_FL == BUMPER_TRIPPED)) {
        currentBumperState_FL = FRONT_LEFT_PRESSED;
        thisEvent.EventType = currentBumperState_FL;
        thisEvent.EventParam = (uint16_t) currentBumperVal_FL;
        returnVal = TRUE;
        lastBumperState_FL = currentBumperState_FL;
#ifndef EVENTCHECKER_TEST           // keep this as is for test harness
        PostGenericService(thisEvent);
#else
        SaveEvent(thisEvent);
#endif
    } else {
       currentBumperState_FL = FRONT_LEFT_UNPRESSED;
    }

    lastBumperStates_FL[2] = lastBumperStates_FL[1];
    lastBumperStates_FL[1] = lastBumperStates_FL[0];
    lastBumperStates_FL[0] = currentBumperVal_FL;

    return returnVal;
}

uint8_t CheckFrontRightBumperPressed(void){
    static uint8_t lastBumperStates_FR[3] = { BUMPER_NOT_TRIPPED,
                                            BUMPER_NOT_TRIPPED, BUMPER_NOT_TRIPPED};

    static ES_EventTyp_t lastBumperState_FR = FRONT_RIGHT_UNPRESSED;
    ES_EventTyp_t currentBumperState_FR;
    ES_Event thisEvent;
    uint8_t returnVal = FALSE;
    uint16_t currentBumperVal_FR = Roach_ReadFrontRightBumper(); // read the bumper value
    // IF bumper was PRESSED for 3 states AND was UNPRESSED 4 states ago => TRANSITION
    if ( (currentBumperVal_FR != lastBumperStates_FR[2]) && (currentBumperVal_FR == lastBumperStates_FR[1]) &&
         (currentBumperVal_FR == lastBumperStates_FR[0]) && (currentBumperVal_FR == BUMPER_TRIPPED)) {
        currentBumperState_FR = FRONT_RIGHT_PRESSED;
        thisEvent.EventType = currentBumperState_FR;
        thisEvent.EventParam = (uint16_t) currentBumperVal_FR;
        returnVal = TRUE;
        lastBumperState_FR = currentBumperState_FR;
#ifndef EVENTCHECKER_TEST           // keep this as is for test harness
        PostGenericService(thisEvent);
#else
        SaveEvent(thisEvent);
#endif
    } else {
       currentBumperState_FR = FRONT_RIGHT_UNPRESSED;
    }

    lastBumperStates_FR[2] = lastBumperStates_FR[1];
    lastBumperStates_FR[1] = lastBumperStates_FR[0];
    lastBumperStates_FR[0] = currentBumperVal_FR;

    return returnVal;
}


/*
* The Test Harness for the event checkers is conditionally compiled using
* the EVENTCHECKER_TEST macro (defined either in the file or at the project level).
* No other main() can exist within the project.
*
* It requires a valid ES_Configure.h file in the project with the correct events in
* the enum, and the correct list of event checkers in the EVENT_CHECK_LIST.
*
* The test harness will run each of your event detectors identically to the way the
* ES_Framework will call them, and if an event is detected it will print out the function
* name, event, and event parameter. Use this to test your event checking code and
* ensure that it is fully functional.
*
* If you are locking up the output, most likely you are generating too many events.
* Remember that events are detectable changes, not a state in itself.
*
* Once you have fully tested your event checking code, you can leave it in its own
* project and point to it from your other projects. If the EVENTCHECKER_TEST marco is
* defined in the project, no changes are necessary for your event checkers to work
* with your other projects.
*/
#ifdef EVENTCHECKER_TEST
#include <stdio.h>
static uint8_t(*EventList[])(void) = {EVENT_CHECK_LIST};

void PrintEvent(void);

//void main(void) {
//   BOARD_Init();
//   Roach_Init();
//   /* user initialization code goes here */
//
//   // Do not alter anything below this line
//   int i;
//
//   printf("\r\nEvent checking test harness for %s", __FILE__);
//
//   while (1) {
//       if (IsTransmitEmpty()) {
//           for (i = 0; i< sizeof (EventList) >> 2; i++) {
//               if (EventList[i]() == TRUE) {
//                   PrintEvent();
//                   break;
//               }
//
//           }
//       }
//   }
//}

void PrintEvent(void) {
   printf("\r\nFunc: %s\tEvent: %s\tParam: 0x%X", eventName,
           EventNames[storedEvent.EventType], storedEvent.EventParam);
}
#endif
